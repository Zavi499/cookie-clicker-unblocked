

# This version can be embedded into places like google sites without annoying popups.

Original game here: http://orteil.dashnet.org/cookieclicker/
